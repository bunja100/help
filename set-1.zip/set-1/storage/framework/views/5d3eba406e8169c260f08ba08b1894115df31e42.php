<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                        <div class="panel-heading">
                          Patients
                            <a href="<?php echo e('create'); ?>" class="btn btn-primary btn-sm pull-right"><span
                                        class="glyphicon glyphicon-pencil"></span>
                                Create
                            </a>
                        </div>
                    <div class="panel-body">

                      <table class="table active">
                        <tr>
                          <td>Total Registered</td>
                          <th><?php echo e(App\Patient::count()); ?></th>
                        </tr>
                          <tr>
                            <td>Total Boys</td>
                            <th><?php echo e(App\Patient::where('sex', 'male')->count()); ?></th>
                          </tr>
                          <tr>
                            <td>Total girls</td>
                            <th><?php echo e(App\Patient::where('sex', 'Female')->count()); ?></th>
                          </tr>
                      </table>

                      <div class="form-group row" >
                          <div class="col-md-6 col-md-offset-3">
                            <br>
                              <form class="" action="<?php echo e(url('/search')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                  <div class="row">
                                    <div class="col-8">
                                      <input type="text" name="search" class="form-control" placeholder="search record">
                                    </div>
                                      <div class="col-4">
                                        <span class="input-group-btn">
                                          <button type="submit" class="btn btn-default">FIND</button>
                                        </span>
                                      </div>
                                  </div>
                                </div>
                              </form>
                          </div>
                    </div>
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Gender</th>
                                <th>D.O.B</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($record->first_name); ?></td>
                                    <td><?php echo e($record->last_name); ?></td>
                                    <td><?php echo e($record->place_of_birth); ?></td>
                                    <td><?php echo e($record->sex); ?></td>
                                    <td><a href="<?php echo e(route('patient', $record->id)); ?>">View</a></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>