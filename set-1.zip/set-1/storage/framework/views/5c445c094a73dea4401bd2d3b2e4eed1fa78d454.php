<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                        <div class="panel-heading">
                            <a href="<?php echo e('create'); ?>" class="btn btn-primary"><span
                                        class="glyphicon glyphicon-pencil"></span>
                                Create
                            </a>
                        </div>
                    <?php else: ?>
                    <?php endif; ?>

                    <div class="panel-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Gender</th>
                                <th>D.O.B</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($record->first_name); ?></td>
                                    <td><?php echo e($record->last_name); ?></td>
                                    <td><?php echo e($record->place_of_birth); ?></td>
                                    <td><?php echo e($record->sex); ?></td>
                                    <td><a href="<?php echo e(route('patient', $record->id)); ?>">View</a></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>