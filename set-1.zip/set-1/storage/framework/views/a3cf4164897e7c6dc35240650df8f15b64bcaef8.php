<div class="card">
  <h1>Birth Certificate Card</h2>
  <h2>
    <small>First Name :</small>
    <?php echo e($patient->first_name); ?>

    <small>Last Name :</small>
    <?php echo e($patient->last_name); ?>

    <br>
      <small> Sex :</small>
    <?php echo e($patient->sex); ?>

      <small>Date of Birth :</small>
    <?php echo e($patient->date_of_birth); ?>

    <br>
      <small>immunisation :</small>
    <?php echo e($patient->immunisation); ?>

      <small>Record of immunisation :</small>
    <?php echo e($patient->rec_of_imm); ?>

<br>
      <small>Fathers name :</small>
    <?php echo e($father->fathers_name); ?>

    <small>Occupation of Father :</small>
    <?php echo e($father->Occupation_of_father); ?>

    <br>
    <small>address of father :</small>
    <?php echo e($father->address_of_father); ?>


    <small>mothers name :</small>
    <?php echo e($mother->mothers_name); ?>

    <br>
    <small>Occupation of mother :</small>
    <?php echo e($mother->Occupation_of_mother); ?>

    <small>address of mother:</small>
    <?php echo e($mother->address_of_mother); ?>


  </h2>

</div>
<style media="screen">
  .card{
    width: 80%;
    margin: auto;
    padding: 25px;
    border: 1px solid #555;
    border-radius: 15px;
    background-image: url('<?php echo e(asset('')); ?>');
  }
  small{
    color: #555;
  }
</style>
